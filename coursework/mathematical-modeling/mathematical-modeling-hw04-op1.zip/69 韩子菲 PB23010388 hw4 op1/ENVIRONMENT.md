# 环境配置与依赖说明

本实验使用 Python 实现，主要依赖 PyTorch 的自动微分功能计算网络解的梯度。

## 推荐环境

- Python 3.11
- PyTorch 2.0 或更高版本
- NumPy 2.0 或更高版本
- SciPy 1.12 或更高版本
- Pandas 2.0 或更高版本
- Matplotlib 3.8 或更高版本


## 运行实验

运行完整实验：

运行run_experiments.py


## 输出文件

实验结果会写入：

- `results/metrics.csv`：误差结果表；
- `results/experiment_config.csv`：实验参数配置；
- `figures/`：报告中使用的图像。


