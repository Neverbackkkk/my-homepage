# 文件说明

本文档说明本目录中各文件和文件夹的用途。

## 根目录文件

- `ENVIRONMENT.md`：中文环境配置、依赖包列表和运行说明。
- `run_experiments.py`：主实验脚本。

## 源代码

- `src/deep_ritz.py`：Deep Ritz 实现，包括：
  - Poisson 算例的解析解和右端项；
  - 区域内部与边界采样函数；
  - ResNet 型神经网络；
  - Deep Ritz 能量损失；
  - Adam 随机小批量优化更新；
  - FDM 参考解；
  - 误差计算函数。
- `src/__init__.py`：Python 包标记文件。

## 实验报告

- `report/report.pdf`：最终实验报告 PDF。

## 图像结果

`figures/` 文件夹保存报告中使用的图像：

- `resnet_random_solution.png`：主模型数值解、解析解和误差图。
- `training_curves.png`：训练过程中的损失和误差曲线。
- `variant_error_heatmaps.png`：不同模型的误差热图。
- `cross_section.png`：在 \(y=0.5\) 截面上的数值解对比。

## 数值结果

`results/` 文件夹保存正式实验的表格结果：

- `metrics.csv`：各方法的误差表。
- `metrics.json`：与 `metrics.csv` 内容相同的 JSON 格式结果。
- `experiment_config.csv`：实验超参数配置。
