from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch

from src.deep_ritz import TrainConfig, save_config, solve_fdm, train_variant


ROOT = Path(__file__).resolve().parent
FIG_DIR = ROOT / "figures"
RESULT_DIR = ROOT / "results"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run Deep Ritz experiments for Poisson equation.")
    parser.add_argument("--epochs", type=int, default=3000, help="Epochs for each neural run.")
    parser.add_argument("--quick", action="store_true", help="Run a faster smoke-test setting.")
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--optimizer", choices=["adam_sgd", "sgd"], default="adam_sgd")
    return parser.parse_args()


def save_grid_npz(name: str, grid: dict[str, np.ndarray]) -> None:
    np.savez_compressed(RESULT_DIR / f"{name}_grid.npz", **grid)


def plot_training(histories: dict[str, pd.DataFrame]) -> None:
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.2), dpi=160)
    for name, history in histories.items():
        axes[0].plot(history["epoch"], history["loss"], label=name)
        axes[1].plot(history["epoch"], history["l2_error"], label=name)
    axes[0].set_title("Energy loss")
    axes[0].set_xlabel("epoch")
    axes[0].set_ylabel("loss")
    axes[0].grid(alpha=0.25)
    axes[1].set_title("Grid L2 error")
    axes[1].set_xlabel("epoch")
    axes[1].set_ylabel("RMS error")
    axes[1].set_yscale("log")
    axes[1].grid(alpha=0.25)
    axes[1].legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "training_curves.png")
    plt.close(fig)


def plot_solution(grid: dict[str, np.ndarray], name: str) -> None:
    fig, axes = plt.subplots(1, 3, figsize=(12, 3.7), dpi=170)
    items = [
        ("Exact solution", grid["u_exact"], "viridis"),
        ("Deep Ritz solution", grid["u_pred"], "viridis"),
        ("Absolute error", grid["abs_error"], "magma"),
    ]
    for ax, (title, values, cmap) in zip(axes, items):
        im = ax.imshow(
            values,
            extent=[0, 1, 0, 1],
            origin="lower",
            cmap=cmap,
            aspect="equal",
        )
        ax.set_title(title)
        ax.set_xlabel("x")
        ax.set_ylabel("y")
        fig.colorbar(im, ax=ax, shrink=0.82)
    fig.tight_layout()
    fig.savefig(FIG_DIR / f"{name}_solution.png")
    plt.close(fig)


def plot_variant_errors(grids: dict[str, dict[str, np.ndarray]]) -> None:
    names = list(grids.keys())
    fig, axes = plt.subplots(1, len(names), figsize=(4.0 * len(names), 3.6), dpi=170)
    if len(names) == 1:
        axes = [axes]
    vmax = max(float(np.max(grids[name]["abs_error"])) for name in names)
    for ax, name in zip(axes, names):
        im = ax.imshow(
            grids[name]["abs_error"],
            extent=[0, 1, 0, 1],
            origin="lower",
            cmap="magma",
            vmin=0,
            vmax=vmax,
            aspect="equal",
        )
        ax.set_title(name)
        ax.set_xlabel("x")
        ax.set_ylabel("y")
        fig.colorbar(im, ax=ax, shrink=0.82)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "variant_error_heatmaps.png")
    plt.close(fig)


def plot_cross_section(grids: dict[str, dict[str, np.ndarray]]) -> None:
    fig, ax = plt.subplots(figsize=(7.4, 4.4), dpi=170)
    first = next(iter(grids.values()))
    mid = first["x"].shape[0] // 2
    ax.plot(first["x"][mid], first["u_exact"][mid], color="black", lw=2.2, label="exact")
    for name, grid in grids.items():
        mid = grid["x"].shape[0] // 2
        ax.plot(grid["x"][mid], grid["u_pred"][mid], lw=1.4, label=name)
    ax.set_title("Cross section at y = 0.5")
    ax.set_xlabel("x")
    ax.set_ylabel("u(x, 0.5)")
    ax.grid(alpha=0.25)
    ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "cross_section.png")
    plt.close(fig)


def main() -> None:
    args = parse_args()
    FIG_DIR.mkdir(exist_ok=True)
    RESULT_DIR.mkdir(exist_ok=True)

    epochs = 600 if args.quick else args.epochs
    eval_grid = 61 if args.quick else 101
    base = dict(
        epochs=epochs,
        interior_batch=768 if args.quick else 1536,
        boundary_batch=384 if args.quick else 768,
        lr=1.5e-3,
        beta=100.0,
        width=48 if args.quick else 64,
        depth=3 if args.quick else 4,
        optimizer=args.optimizer,
        device=args.device,
        log_every=25 if args.quick else 50,
        eval_grid=eval_grid,
    )
    configs = [
        TrainConfig(name="resnet_random", resnet=True, fixed_collocation=False, seed=2026, **base),
        TrainConfig(name="resnet_fixed", resnet=True, fixed_collocation=True, seed=2026, **base),
        TrainConfig(name="mlp_random", resnet=False, fixed_collocation=False, seed=2026, **base),
    ]
    save_config(RESULT_DIR / "experiment_config.csv", configs)

    histories: dict[str, pd.DataFrame] = {}
    grids: dict[str, dict[str, np.ndarray]] = {}
    metrics = []

    for cfg in configs:
        print(f"[run] {cfg.name}: resnet={cfg.resnet}, fixed={cfg.fixed_collocation}")
        model, history, final_metrics, grid = train_variant(cfg)
        histories[cfg.name] = history
        grids[cfg.name] = grid
        metrics.append(final_metrics)
        history.to_csv(RESULT_DIR / f"history_{cfg.name}.csv", index=False)
        save_grid_npz(cfg.name, grid)
        torch.save(model.state_dict(), RESULT_DIR / f"{cfg.name}.pt")

    fdm_grid, fdm_metrics = solve_fdm(n=64)
    grids["fdm_64"] = fdm_grid
    metrics.append(fdm_metrics)
    save_grid_npz("fdm_64", fdm_grid)

    metrics_df = pd.DataFrame(metrics)
    metrics_df.to_csv(RESULT_DIR / "metrics.csv", index=False)
    (RESULT_DIR / "metrics.json").write_text(
        json.dumps(metrics_df.to_dict(orient="records"), indent=2),
        encoding="utf-8",
    )

    plot_training(histories)
    plot_solution(grids["resnet_random"], "resnet_random")
    plot_variant_errors(grids)
    plot_cross_section(grids)

    print(metrics_df.to_string(index=False))


if __name__ == "__main__":
    main()
