from __future__ import annotations

import math
import random
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Dict, Iterable, Tuple

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from scipy.sparse import diags, eye, kron
from scipy.sparse.linalg import spsolve


@dataclass
class TrainConfig:
    name: str
    epochs: int = 2000
    interior_batch: int = 1024
    boundary_batch: int = 512
    lr: float = 2.0e-3
    beta: float = 100.0
    width: int = 64
    depth: int = 4
    resnet: bool = True
    fixed_collocation: bool = False
    optimizer: str = "adam_sgd"
    seed: int = 2026
    device: str = "cpu"
    log_every: int = 50
    eval_grid: int = 81


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def exact_u(x: torch.Tensor) -> torch.Tensor:
    return torch.sin(math.pi * x[:, 0:1]) * torch.sin(math.pi * x[:, 1:2])


def rhs_f(x: torch.Tensor) -> torch.Tensor:
    return 2.0 * math.pi**2 * exact_u(x)


def boundary_g(x: torch.Tensor) -> torch.Tensor:
    return exact_u(x)


def sample_interior(n: int, device: str) -> torch.Tensor:
    return torch.rand(n, 2, device=device)


def sample_boundary(n: int, device: str) -> torch.Tensor:
    t = torch.rand(n, 1, device=device)
    side = torch.randint(0, 4, (n, 1), device=device)
    points = torch.zeros(n, 2, device=device)

    mask = side[:, 0] == 0
    points[mask, 0] = t[mask, 0]
    points[mask, 1] = 0.0

    mask = side[:, 0] == 1
    points[mask, 0] = t[mask, 0]
    points[mask, 1] = 1.0

    mask = side[:, 0] == 2
    points[mask, 0] = 0.0
    points[mask, 1] = t[mask, 0]

    mask = side[:, 0] == 3
    points[mask, 0] = 1.0
    points[mask, 1] = t[mask, 0]
    return points


class ResidualBlock(nn.Module):
    def __init__(self, width: int) -> None:
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(width, width),
            nn.Tanh(),
            nn.Linear(width, width),
            nn.Tanh(),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return x + 0.5 * self.net(x)


class DeepRitzNet(nn.Module):
    def __init__(self, width: int = 64, depth: int = 4, resnet: bool = True) -> None:
        super().__init__()
        layers: list[nn.Module] = [nn.Linear(2, width), nn.Tanh()]
        if resnet:
            layers.extend(ResidualBlock(width) for _ in range(depth))
        else:
            for _ in range(2 * depth):
                layers.extend([nn.Linear(width, width), nn.Tanh()])
        layers.append(nn.Linear(width, 1))
        self.net = nn.Sequential(*layers)
        self.apply(self._init)

    @staticmethod
    def _init(module: nn.Module) -> None:
        if isinstance(module, nn.Linear):
            nn.init.xavier_uniform_(module.weight)
            nn.init.zeros_(module.bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


def energy_loss(
    model: nn.Module,
    interior: torch.Tensor,
    boundary: torch.Tensor,
    beta: float,
) -> torch.Tensor:
    interior = interior.detach().clone().requires_grad_(True)
    boundary = boundary.detach().clone()

    u = model(interior)
    grad_u = torch.autograd.grad(
        u,
        interior,
        grad_outputs=torch.ones_like(u),
        create_graph=True,
        retain_graph=True,
    )[0]
    interior_energy = 0.5 * (grad_u**2).sum(dim=1, keepdim=True) - rhs_f(interior) * u
    boundary_penalty = (model(boundary) - boundary_g(boundary)) ** 2

    domain_area = 1.0
    boundary_measure = 4.0
    return domain_area * interior_energy.mean() + beta * boundary_measure * boundary_penalty.mean()


class AdamSGD(torch.optim.Optimizer):
    """Adam-style stochastic gradient descent update used in the Deep Ritz paper."""

    def __init__(
        self,
        params,
        lr: float = 1.0e-3,
        betas: tuple[float, float] = (0.9, 0.999),
        eps: float = 1.0e-8,
    ) -> None:
        defaults = {"lr": lr, "betas": betas, "eps": eps}
        super().__init__(params, defaults)

    @torch.no_grad()
    def step(self, closure=None):
        loss = None
        if closure is not None:
            with torch.enable_grad():
                loss = closure()

        for group in self.param_groups:
            lr = group["lr"]
            beta1, beta2 = group["betas"]
            eps = group["eps"]
            for param in group["params"]:
                if param.grad is None:
                    continue
                grad = param.grad
                state = self.state[param]
                if len(state) == 0:
                    state["step"] = 0
                    state["exp_avg"] = torch.zeros_like(param)
                    state["exp_avg_sq"] = torch.zeros_like(param)

                exp_avg = state["exp_avg"]
                exp_avg_sq = state["exp_avg_sq"]
                state["step"] += 1

                exp_avg.mul_(beta1).add_(grad, alpha=1.0 - beta1)
                exp_avg_sq.mul_(beta2).addcmul_(grad, grad, value=1.0 - beta2)

                bias_correction1 = 1.0 - beta1 ** state["step"]
                bias_correction2 = 1.0 - beta2 ** state["step"]
                step_size = lr * math.sqrt(bias_correction2) / bias_correction1
                denom = exp_avg_sq.sqrt().add_(eps)
                param.addcdiv_(exp_avg, denom, value=-step_size)
        return loss


def make_optimizer(model: nn.Module, cfg: TrainConfig) -> torch.optim.Optimizer:
    if cfg.optimizer.lower() == "sgd":
        return torch.optim.SGD(model.parameters(), lr=cfg.lr, momentum=0.9)
    if cfg.optimizer.lower() == "adam_sgd":
        return AdamSGD(model.parameters(), lr=cfg.lr)
    raise ValueError(f"Unknown optimizer: {cfg.optimizer}")


@torch.no_grad()
def predict_grid(model: nn.Module, grid_n: int, device: str) -> Dict[str, np.ndarray]:
    x = np.linspace(0.0, 1.0, grid_n)
    y = np.linspace(0.0, 1.0, grid_n)
    xx, yy = np.meshgrid(x, y, indexing="xy")
    pts_np = np.column_stack([xx.ravel(), yy.ravel()]).astype(np.float32)
    pts = torch.from_numpy(pts_np).to(device)

    pred_chunks = []
    for chunk in torch.split(pts, 8192):
        pred_chunks.append(model(chunk).cpu())
    pred = torch.cat(pred_chunks, dim=0).numpy().reshape(grid_n, grid_n)

    exact = (
        np.sin(math.pi * xx) * np.sin(math.pi * yy)
    )
    err = pred - exact
    return {
        "x": xx,
        "y": yy,
        "u_pred": pred,
        "u_exact": exact,
        "error": err,
        "abs_error": np.abs(err),
    }


def grid_metrics(grid: Dict[str, np.ndarray]) -> Dict[str, float]:
    err = grid["error"]
    return {
        "l2_error": float(np.sqrt(np.mean(err**2))),
        "linf_error": float(np.max(np.abs(err))),
    }


def boundary_metrics(model: nn.Module, device: str, n: int = 2000) -> Dict[str, float]:
    pts = sample_boundary(n, device)
    with torch.no_grad():
        err = model(pts) - boundary_g(pts)
    return {
        "boundary_l2": float(torch.sqrt(torch.mean(err**2)).cpu()),
        "boundary_linf": float(torch.max(torch.abs(err)).cpu()),
    }


def train_variant(cfg: TrainConfig) -> Tuple[nn.Module, pd.DataFrame, Dict[str, float], Dict[str, np.ndarray]]:
    set_seed(cfg.seed)
    device = cfg.device
    model = DeepRitzNet(width=cfg.width, depth=cfg.depth, resnet=cfg.resnet).to(device)
    optimizer = make_optimizer(model, cfg)

    fixed_interior = None
    fixed_boundary = None
    if cfg.fixed_collocation:
        fixed_interior = sample_interior(cfg.interior_batch, device)
        fixed_boundary = sample_boundary(cfg.boundary_batch, device)

    history = []
    for epoch in range(1, cfg.epochs + 1):
        if fixed_interior is None or fixed_boundary is None:
            interior = sample_interior(cfg.interior_batch, device)
            boundary = sample_boundary(cfg.boundary_batch, device)
        else:
            interior = fixed_interior
            boundary = fixed_boundary

        optimizer.zero_grad(set_to_none=True)
        loss = energy_loss(model, interior, boundary, cfg.beta)
        loss.backward()
        optimizer.step()

        if epoch == 1 or epoch % cfg.log_every == 0 or epoch == cfg.epochs:
            grid = predict_grid(model, cfg.eval_grid, device)
            metrics = grid_metrics(grid)
            history.append(
                {
                    "epoch": epoch,
                    "loss": float(loss.detach().cpu()),
                    **metrics,
                }
            )

    final_grid = predict_grid(model, cfg.eval_grid, device)
    final_metrics = {
        "name": cfg.name,
        "method": "Deep Ritz",
        "resnet": cfg.resnet,
        "fixed_collocation": cfg.fixed_collocation,
        "optimizer": cfg.optimizer,
        "epochs": cfg.epochs,
        **grid_metrics(final_grid),
        **boundary_metrics(model, device),
    }
    return model, pd.DataFrame(history), final_metrics, final_grid


def solve_fdm(n: int = 64) -> Tuple[Dict[str, np.ndarray], Dict[str, float]]:
    h = 1.0 / (n + 1)
    x_in = np.linspace(h, 1.0 - h, n)
    y_in = np.linspace(h, 1.0 - h, n)
    xx_in, yy_in = np.meshgrid(x_in, y_in, indexing="xy")
    rhs = 2.0 * math.pi**2 * np.sin(math.pi * xx_in) * np.sin(math.pi * yy_in)

    t = diags([-1.0, 2.0, -1.0], [-1, 0, 1], shape=(n, n), format="csr")
    ident = eye(n, format="csr")
    matrix = (kron(ident, t) + kron(t, ident)) / h**2
    u_vec = spsolve(matrix, rhs.ravel())
    u_in = u_vec.reshape(n, n)

    grid_n = n + 2
    x = np.linspace(0.0, 1.0, grid_n)
    y = np.linspace(0.0, 1.0, grid_n)
    xx, yy = np.meshgrid(x, y, indexing="xy")
    pred = np.zeros((grid_n, grid_n))
    pred[1:-1, 1:-1] = u_in
    exact = np.sin(math.pi * xx) * np.sin(math.pi * yy)
    err = pred - exact
    grid = {
        "x": xx,
        "y": yy,
        "u_pred": pred,
        "u_exact": exact,
        "error": err,
        "abs_error": np.abs(err),
    }
    metrics = {
        "name": f"fdm_{n}",
        "method": "FDM",
        "resnet": False,
        "fixed_collocation": False,
        "optimizer": "",
        "epochs": 0,
        **grid_metrics(grid),
        "boundary_l2": 0.0,
        "boundary_linf": 0.0,
    }
    return grid, metrics


def save_config(path: Path, configs: Iterable[TrainConfig]) -> None:
    rows = [asdict(cfg) for cfg in configs]
    pd.DataFrame(rows).to_csv(path, index=False)
