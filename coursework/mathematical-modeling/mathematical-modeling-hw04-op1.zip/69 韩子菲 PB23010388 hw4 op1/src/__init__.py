"""Deep Ritz homework package."""

