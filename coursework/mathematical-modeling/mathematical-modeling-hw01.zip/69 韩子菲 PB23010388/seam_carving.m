%   Copyright 2025, Renjie Chen @ USTC


%% read image
im = imread('peppers.png');

%% draw 2 copies of the image
fig=figure('Units', 'pixel', 'Position', [100,100,1000,700], 'toolbar', 'none');
subplot(121); imshow(im); title({'Input image'});
subplot(122); himg = imshow(im*0); title({'Resized Image', 'Use the blue button to resize the input image'});
hToolResize = uipushtool('CData', reshape(repmat([0 0 1], 100, 1), [10 10 3]), 'TooltipString', 'apply seam carving method to resize image', ...
                        'ClickedCallback', @(~, ~) set(himg, 'cdata', seam_carve_image(im, size(im,1:2)-[0 300])));

%% TODO: implement function: searm_carve_image
% check the title above the image for how to use the user-interface to resize the input image
function im = seam_carve_image(im, sz)

    % im = imresize(im, sz);

    costfunction = @(im) sum( imfilter(im, [.5 1 .5; 1 -6 1; .5 1 .5]).^2, 3 );

    k = size(im,2) - sz(2);
    for i = 1:k
        G = costfunction(double(im));
        %% find a seam in G
        [m, n] = size(G);
        dp = zeros(m, n);
        dir = zeros(m, n); 
        dp(1, :) = G(1, :);

        for r = 2:m
            % 两端补inf防越界
            L = [inf, dp(r-1, 1:n-1)];
            C = dp(r-1, :);
            R = [dp(r-1, 2:n), inf];
            
            [v, p] = min([L; C; R]); 
            dp(r, :) = G(r, :) + v;
            dir(r, :) = p - 2; % 偏移: -1, 0, 1
        end
        
        s = zeros(m, 1);
        [~, c] = min(dp(m, :));
        s(m) = c;
        
        % 自底向上回溯
        for r = m-1:-1:1
            c = c + dir(r+1, c)
            s(r) = c;
        end
        %% remove seam from im
        del = sub2ind([n, m], s, (1:m)'); 
        res = zeros(m, n-1, 3, 'uint8');
        
        for ch = 1:3
            t = im(:,:,ch)';
            t(del) = []; 
            res(:,:,ch) = reshape(t, n-1, m)'; 
        end
        im = res;
    end

end