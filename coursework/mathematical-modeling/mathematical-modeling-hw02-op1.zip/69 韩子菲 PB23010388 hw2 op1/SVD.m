%%GUI与初始化
function Compression_GUI()
    f = uifigure('Name', 'SVD & DWT', 'Position', [100, 100, 950, 550]);
    
    ax1 = uiaxes(f, 'Position', [30, 180, 400, 320]); title(ax1, '原图 (Source Image)');
    ax2 = uiaxes(f, 'Position', [500, 180, 400, 320]); title(ax2, '处理后图像 (Compressed Image)');
    ax1.XTick = []; ax1.YTick = []; ax2.XTick = []; ax2.YTick = [];

    I = im2double(imread('peppers.png'));
    % N = 256;
    % [X, Y] = meshgrid(1:N, 1:N);
    % I_sine = 0.5 * sin(2*pi * 60 * X / N) .* cos(2*pi * 60 * Y / N) + 0.5;
    % imwrite(I_sine, 'math_sine_grating.png');
    % I = im2double(imread('math_sine_grating.png'));
    imshow(I, 'Parent', ax1);
    [H, W, C] = size(I);
    
    kMax = min(H, W); 
    k_init = 30; 
    
    pnl = uipanel(f, 'Position', [30, 20, 870, 130], 'Title', '控制台与指标评估');
    
    uilabel(pnl, 'Position', [20, 70, 100, 22], 'Text', 'SVD 保留秩 (k):');
    
    sld = uislider(pnl, 'Position', [120, 80, 150, 3], 'Limits', [1, kMax], 'Value', k_init);
    
    ef_k = uieditfield(pnl, 'numeric', 'Position', [280, 70, 45, 22], 'Value', k_init, 'Limits', [1, kMax]);
    
    btnSVD   = uibutton(pnl, 'Position', [340, 65, 110, 30], 'Text', 'SVD');
    btnDWT   = uibutton(pnl, 'Position', [480, 65, 110, 30], 'Text', '对比 DWT');
    btnReset = uibutton(pnl, 'Position', [620, 65, 110, 30], 'Text', '显示原图');
    
    tMethod = uilabel(pnl, 'Position', [20, 15, 200, 22], 'Text', '当前算法:SVD', 'FontWeight', 'bold', 'FontColor', 'blue');
    tPSNR = uilabel(pnl, 'Position', [220, 15, 150, 22], 'Text', 'PSNR: -- dB', 'FontWeight', 'bold');
    tSSIM = uilabel(pnl, 'Position', [380, 15, 150, 22], 'Text', 'SSIM: --', 'FontWeight', 'bold');
    tCR = uilabel(pnl, 'Position', [540, 15, 200, 22], 'Text', '预估压缩比: --', 'FontWeight', 'bold');
    
    sld.ValueChangedFcn = @(src, event) syncSliderToEdit(round(src.Value));
    ef_k.ValueChangedFcn = @(src, event) syncEditToSlider(round(src.Value));
    
    btnSVD.ButtonPushedFcn = @(src, event) runSVD(round(ef_k.Value));
    btnDWT.ButtonPushedFcn = @(src, event) runDWT();
    btnReset.ButtonPushedFcn = @(src, event) resetView();
    
    % 启动时默认执行一次 SVD
    runSVD(k_init); 

    %% 交互回调函数
    % 滑动条驱动输入框
    function syncSliderToEdit(rk)
        ef_k.Value = rk;
        runSVD(rk);
    end

    function syncEditToSlider(rk)
        if rk < 1, rk = 1; end
        if rk > kMax, rk = kMax; end
        
        ef_k.Value = rk;
        sld.Value = rk;
        runSVD(rk);
    end

    %% 核心运行逻辑
    function runSVD(rk)
        I2 = zeros(H, W, C);
        for c = 1:C
            [Uk, Sk, Vk] = fast_mySVD(I(:,:,c), rk);
            I2(:,:,c) = Uk * Sk * Vk';
        end
        I2 = max(0, min(1, I2)); 
        
        imshow(I2, 'Parent', ax2); 
        title(ax2, sprintf('SVD (Rank = %d)', rk));
        tMethod.Text = '当前算法: SVD';
        
        calcMetrics(I2, (H*W) / (rk*(H+W+1))); 
    end

    function runDWT()
        try
            I2 = zeros(H, W, C);
            for c = 1:C
                [cA, cH, cV, cD] = dwt2(I(:,:,c), 'haar');
                I2(:,:,c) = idwt2(cA, zeros(size(cH)), zeros(size(cV)), zeros(size(cD)), 'haar', size(I(:,:,c)));
            end
            I2 = max(0, min(1, I2));
            
            imshow(I2, 'Parent', ax2); title(ax2, 'DWT 压缩 (丢弃高频细节)');
            tMethod.Text = '当前算法: DWT (小波变换)';
            calcMetrics(I2, 4); 
        catch
            uialert(f, '缺少 Wavelet Toolbox，无法演示小波。', '依赖错误');
        end
    end

    function resetView()
        imshow(I, 'Parent', ax2); title(ax2, '原始图像');
        tMethod.Text = '当前状态: 未压缩';
        calcMetrics(I, 1);
    end

    function calcMetrics(imgOut, cr)
        mse = mean((I(:) - imgOut(:)).^2);
        if mse < 1e-10, psnr = Inf; else, psnr = 10 * log10(1 / mse); end
        
        sm = ssim(imgOut, I);
        tSSIM.Text = sprintf('SSIM: %.4f', sm);
        tPSNR.Text = sprintf('PSNR: %.2f dB', psnr);
        tCR.Text = sprintf('预估压缩比: %.2f : 1', cr);
    end
end

%%SVD分解函数
function [U, S, V] = fast_mySVD(A, k)
    [m, n] = size(A);
    
    if m >= n
        CovMat = A' * A;
        [V, D] = subspace_iteration(CovMat, k);
        sig = sqrt(max(diag(D), 0));
        S = diag(sig);
        
        U = zeros(m, k);
        for i = 1:k
            if sig(i) > 1e-10
                U(:, i) = (A * V(:, i)) / sig(i);
            end
        end
    else
        CovMat = A * A';
        [U, D] = subspace_iteration(CovMat, k);
        sig = sqrt(max(diag(D), 0));
        S = diag(sig);
        
        V = zeros(n, k);
        for i = 1:k
            if sig(i) > 1e-10
                V(:, i) = (A' * U(:, i)) / sig(i);
            end
        end
    end
end

function [V, D] = subspace_iteration(A, k)
    n = size(A, 1);
    V_iter = eye(n, k); 
    numIter = 25; 
    for i = 1:numIter
        Z = A * V_iter;
        V_iter = vectorized_MGS(Z);
    end
    
    V = V_iter;
    D = V' * A * V; 
end

function Q = vectorized_MGS(A)
    [m, n] = size(A);
    Q = zeros(m, n);
    for j = 1:n

        v = A(:, j);
        if j > 1
            v = v - Q(:, 1:j-1) * (Q(:, 1:j-1)' * v);
        end
        norm_v = norm(v);
        if norm_v > 1e-10
            Q(:, j) = v / norm_v;
        end
    end
end