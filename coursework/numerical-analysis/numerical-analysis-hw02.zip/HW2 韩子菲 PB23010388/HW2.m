clear; clc; close all;


f = @(x) 1 ./ (1 + 25 * x.^2); 


i_eval = 0:100;
y_eval = i_eval ./ 50 - 1; 
fy_eval = f(y_eval);


N_values = [5, 10, 20, 40];

% 存储 N=20 时的绘图数据
plot_y1 = zeros(size(y_eval));
plot_y2 = zeros(size(y_eval));
plot_x1 = []; plot_x2 = [];

% 主循环
for k = 1:length(N_values)
    N = N_values(k);
    
    fprintf('N=%d\n', N);
    
    i_idx = 0:N;
    
    x1 = 1 - (2/N) * i_idx;
    y1 = f(x1);
    
    x2 = -cos((2 * i_idx + 1) / (2 * N + 2) * pi);
    y2 = f(x2);
    
    p1 = newton_interp(x1, y1, y_eval);
    p2 = newton_interp(x2, y2, y_eval);
    
    max_err1 = max(abs(fy_eval - p1));
    max_err2 = max(abs(fy_eval - p2));
    
    fprintf('Max Error of grid (1): %e\n', max_err1);
    fprintf('Max Error of grid (2): %e\n', max_err2);
    
    if N == 20
        plot_x1 = x1; plot_y1_nodes = y1; plot_p1 = p1;
        plot_x2 = x2; plot_y2_nodes = y2; plot_p2 = p2;
    end
end

% 4. 绘制 N=20 时的图像
figure;
hold on;

plot(y_eval, fy_eval, 'k-', 'LineWidth', 2);

% 等距节点插值曲线及节点
plot(y_eval, plot_p1, 'r--', 'LineWidth', 1.5);
plot(plot_x1, plot_y1_nodes, 'ro', 'MarkerSize', 6);

% 切比雪夫节点插值曲线及节点
plot(y_eval, plot_p2, 'b-.', 'LineWidth', 1.5);
plot(plot_x2, plot_y2_nodes, 'b*', 'MarkerSize', 6);


legend('f(x) 原函数', 'Grid 1 插值 (等距)', 'Grid 1 节点', ...
       'Grid 2 插值 (切比雪夫)', 'Grid 2 节点', 'Location', 'Best');
title('N = 20 时的 Newton 插值多项式与原函数对比');
xlabel('x');
ylabel('f(x)');
grid on;
hold off;


% Newton 插值计算

function p = newton_interp(x_nodes, y_nodes, x_eval)
    
    n = length(x_nodes);
    m = length(x_eval);
    
    % 计算差商表
    a = y_nodes;
    for j = 2:n
        % 从后往前更新，避免覆盖当前阶需要的上一阶数据
        for i = n:-1:j
            a(i) = (a(i) - a(i-1)) / (x_nodes(i) - x_nodes(i-j+1));
        end
    end
    
    % 嵌套求解多项式值
    p = a(n) * ones(1, m);
    for i = n-1:-1:1
        p = p .* (x_eval - x_nodes(i)) + a(i);
    end
end