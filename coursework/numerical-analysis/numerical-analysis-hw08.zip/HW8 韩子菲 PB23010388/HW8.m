clc; clear;

n = 7; 

disp('=== 测试积分 a ===');
a1 = 0; b1 = 1;
R1 = romberg(@func_a, a1, b1, n);
print_array(R1);

disp('=== 测试积分 b ===');
a2 = -1; b2 = 1;
R2 = romberg(@func_b, a2, b2, n);
print_array(R2);

disp('=== 测试积分 c (换元后) ===');
a3 = 0; b3 = 1;
R3 = romberg(@func_c, a3, b3, n);
print_array(R3);


% 龙贝格算法
function R = romberg(f, a, b, n)
    R = zeros(n, n); 
    h = b - a;      
    
    R(1,1) = (h / 2) * (f(a) + f(b));
    
    for i = 2:n
        h = h / 2; 
        
        sum_f = 0;
        for k = 1:(2^(i-2))
            x = a + (2*k - 1) * h;
            sum_f = sum_f + f(x);
        end
        
        R(i,1) = R(i-1,1) / 2 + h * sum_f;
        
        for j = 2:i
            R(i,j) = R(i,j-1) + (R(i,j-1) - R(i-1,j-1)) / (4^(j-1) - 1);
        end
    end
end

% 打印下三角阵列
function print_array(R)
    n = size(R, 1);
    for i = 1:n
        for j = 1:i
            fprintf('%10.7f  ', R(i,j)); 
        end
        fprintf('\n');
    end
    fprintf('\n');
end


% 被积函数

% a
function y = func_a(x)
    if x == 0
        y = 1; % 补充定义
    else
        y = sin(x) / x;
    end
end

% b
function y = func_b(x)
    if x == 0
        y = -1; % 补充定义
    elseif abs(x) < 1e-4  % 当x非常靠近0时，使用泰勒展开避免减法
        y = -1 - x - (1/3) * x^2; 
    else
        y = (cos(x) - exp(x)) / sin(x);
    end
end

% c (换元后)
function y = func_c(t)
    if t == 0
        y = 0; % 补充定义
    else
        y = 1 / (t * exp(1/t));
    end
end