clear; clc;
format long e;

Ns = 2.^(3:8);
T = 1;

r1 = solve_root(-1.2, -0.8);
r2 = solve_root(-0.3, 0);
r = r1;

fprintf('roots at t = 1:\n');
fprintf('r1 = %.16e\n', r1);
fprintf('r2 = %.16e\n\n', r2);

ansx = zeros(size(Ns));
err = zeros(size(Ns));
p = NaN(size(Ns));

for k = 1:length(Ns)
    n = Ns(k);
    h = T / n;
    t = 0:h:T;
    x = zeros(1, n + 1);
    x(1) = 0;

    for i = 1:3
        x(i + 1) = rk4(t(i), x(i), h);
    end

    for i = 4:n
        f0 = fun(t(i),     x(i));
        f1 = fun(t(i - 1), x(i - 1));
        f2 = fun(t(i - 2), x(i - 2));
        f3 = fun(t(i - 3), x(i - 3));

        x(i + 1) = x(i) + h * (55*f0 - 59*f1 + 37*f2 - 9*f3) / 24;
    end

    ansx(k) = x(end);
    err(k) = abs(ansx(k) - r);

    if k > 1 && err(k) > 1e-15 && err(k - 1) > 1e-15
        p(k) = log(err(k - 1) / err(k)) / log(Ns(k) / Ns(k - 1));
    end
end

fprintf('    N              x(1)                 error             order\n');
for k = 1:length(Ns)
    fprintf('%5d    % .16e    %.3e', Ns(k), ansx(k), err(k));
    if isnan(p(k))
        fprintf('          --\n');
    else
        fprintf('       %.6f\n', p(k));
    end
end

function y = fun(t, x)
    y = (t - exp(-t)) / (x + exp(x));
end

function y = rk4(t, x, h)
    k1 = fun(t, x);
    k2 = fun(t + h/2, x + h*k1/2);
    k3 = fun(t + h/2, x + h*k2/2);
    k4 = fun(t + h, x + h*k3);
    y = x + h*(k1 + 2*k2 + 2*k3 + k4)/6;
end

function r = solve_root(a, b)
    fa = eqn(a);
    fb = eqn(b);

    for i = 1:100
        c = (a + b) / 2;
        fc = eqn(c);

        if abs(fc) < 1e-15 || abs(b - a) < 1e-15
            r = c;
            return;
        end

        if fa * fc <= 0
            b = c;
            fb = fc;
        else
            a = c;
            fa = fc;
        end
    end

    r = (a + b) / 2;
end

function y = eqn(x)
    y = x^2 - 1 + 2*exp(x) - 2*exp(-1);
end
