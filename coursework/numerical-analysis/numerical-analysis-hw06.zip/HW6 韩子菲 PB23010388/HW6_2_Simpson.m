
clear;clc;

f = @(x) sin(x);

a1 = 0; b1 = 4;
a2 = 0; b2 = 2*pi;

exact_I1 = 1 - cos(4); 
exact_I2 = 0;          

err_trap_1_old = 0; err_simp_1_old = 0;
err_trap_2_old = 0; err_simp_2_old = 0;
N_old = 0;

%% I1
disp('==========================================================================');
disp('积分 I1 = \int_{0}^{4} sin(x) dx');
disp(sprintf('%-4s | %-6s | %-12s | %-12s | %-10s | %-10s', 'k', 'N', 'Trap Error', 'Simp Error', 'Trap Ord', 'Simp Ord'));
disp('--------------------------------------------------------------------------');

for k = 1:12
    N = 2^k; 
    
    trap_val_1 = comp_trapezoidal(f, a1, b1, N);
    simp_val_1 = comp_simpson(f, a1, b1, N);
    
    err_trap_1 = abs(trap_val_1 - exact_I1);
    err_simp_1 = abs(simp_val_1 - exact_I1);
    
    if k > 1
        ord_trap_1 = log(err_trap_1_old / err_trap_1) / log(N / N_old);
        ord_simp_1 = log(err_simp_1_old / err_simp_1) / log(N / N_old);
        
        disp(sprintf('%-4d | %-6d | %-12.4e | %-12.4e | %-10.4f | %-10.4f', ...
            k, N, err_trap_1, err_simp_1, ord_trap_1, ord_simp_1));
    else
        disp(sprintf('%-4d | %-6d | %-12.4e | %-12.4e | %-10s | %-10s', ...
            k, N, err_trap_1, err_simp_1, '-', '-'));
    end
    
    err_trap_1_old = err_trap_1;
    err_simp_1_old = err_simp_1;
    N_old = N;
end

%% I2
disp(' ');
disp('==========================================================================');
disp('积分 I2 = \int_{0}^{2\pi} sin(x) dx');
disp('注: 周期函数在整周期上积分，数值误差会极快跌至机器精度(~1e-16)，导致收敛阶公式失效。');
disp(sprintf('%-4s | %-6s | %-12s | %-12s | %-10s | %-10s', 'k', 'N', 'Trap Error', 'Simp Error', 'Trap Ord', 'Simp Ord'));
disp('--------------------------------------------------------------------------');

N_old = 0;
for k = 1:12
    N = 2^k;
    
    trap_val_2 = comp_trapezoidal(f, a2, b2, N);
    simp_val_2 = comp_simpson(f, a2, b2, N);
    
    err_trap_2 = abs(trap_val_2 - exact_I2);
    err_simp_2 = abs(simp_val_2 - exact_I2);
    
    if k > 1
        % 如果误差已经达到机器精度级别，不再计算阶数
        if err_trap_2 > 1e-14 && err_trap_2_old > 1e-14
            ord_trap_2 = log(err_trap_2_old / err_trap_2) / log(N / N_old);
            str_trap = sprintf('%-10.4f', ord_trap_2);
        else
            str_trap = sprintf('%-10s', 'N/A (~0)');
        end
        
        if err_simp_2 > 1e-14 && err_simp_2_old > 1e-14
            ord_simp_2 = log(err_simp_2_old / err_simp_2) / log(N / N_old);
            str_simp = sprintf('%-10.4f', ord_simp_2);
        else
            str_simp = sprintf('%-10s', 'N/A (~0)');
        end
        
        disp(sprintf('%-4d | %-6d | %-12.4e | %-12.4e | %s | %s', ...
            k, N, err_trap_2, err_simp_2, str_trap, str_simp));
    else
        disp(sprintf('%-4d | %-6d | %-12.4e | %-12.4e | %-10s | %-10s', ...
            k, N, err_trap_2, err_simp_2, '-', '-'));
    end
    
    err_trap_2_old = err_trap_2;
    err_simp_2_old = err_simp_2;
    N_old = N;
end


%% 复化梯形积分公式
function I = comp_trapezoidal(f, a, b, N)
    h = (b - a) / N;
    x = a:h:b;     
    y = f(x);
    I = (h / 2) * (y(1) + 2 * sum(y(2:end-1)) + y(end));
end

%% 复化 Simpson 积分公式
function I = comp_simpson(f, a, b, N)
    
    h = (b - a) / N;
    x = a:h:b;     
    y = f(x);
    
    sum_odd = sum(y(2:2:end-1));  
    sum_even = sum(y(3:2:end-2)); 
    
    I = (h / 3) * (y(1) + 4 * sum_odd + 2 * sum_even + y(end));
end