clear; clc;

h = 1;

%% 题目 1: f(x) = ln(x), x = 3, M = 3
disp('========================================');
disp('题 1: f(x) = ln(x), x = 3, M = 3');
f1 = @(x) log(x);  
x1 = 3;
M1 = 3;
D1 = richardson_extrap(f1, x1, h, M1);
print_matrix(D1);

%% 题目 2: f(x) = tan(x), x = asin(0.8), M = 4
disp('========================================');
disp('题 2: f(x) = tan(x), x = asin(0.8), M = 4');
f2 = @(x) tan(x);
x2 = asin(0.8);  
M2 = 4;
D2 = richardson_extrap(f2, x2, h, M2);
print_matrix(D2);

%% 题目 3: f(x) = sin(x^2 + 1/3*x), x = 0, M = 5
disp('========================================');
disp('题 3: f(x) = sin(x^2 + (1/3)*x), x = 0, M = 5');
f3 = @(x) sin(x^2 + (1/3)*x);
x3 = 0;
M3 = 5;
D3 = richardson_extrap(f3, x3, h, M3);
print_matrix(D3);


%% Richardson 外推法计算导数
function D = richardson_extrap(f, x, h, M)
    D = zeros(M+1, M+1);
    
    for j = 0:M
        h_j = h / (2^j);
        D(j+1, 1) = (f(x + h_j) - f(x - h_j)) / (2 * h_j);
    end
    
    for k = 1:M
        for j = k:M
            D(j+1, k+1) = D(j+1, k) + (D(j+1, k) - D(j, k)) / (4^k - 1);
        end
    end
end

%% 打印函数
function print_matrix(D)
    [rows, ~] = size(D);
    for i = 1:rows
        row_str = '';
        for j = 1:i
            row_str = [row_str, sprintf('%12.8f  ', D(i, j))];
        end
        disp(row_str);
    end
    disp(' '); 
end