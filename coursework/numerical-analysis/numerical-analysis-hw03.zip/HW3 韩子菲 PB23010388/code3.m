
clear; clc;


f = @(x) exp(x);
df_0 = 1;       
df_1 = exp(1); 


N_list = [5, 10, 20, 40];

% 初始化用于存储误差的数组
err1_list = zeros(1, length(N_list));
err2_list = zeros(1, length(N_list));


fprintf('%-5s %-20s %-15s %-20s %-15s\n', 'n', 'Method (1) error', 'order', 'Method (2) error', 'order');
fprintf('--------------------------------------------------------------------------------\n');

for k = 1:length(N_list)
    N = N_list(k);
    h = 1.0 / N; 
    
    % 构造等距节点
    x = linspace(0, 1, N+1)';
    y = f(x);
    
    x_mid = x(1:end-1) + h/2;
    y_exact = f(x_mid);
    
   
   % 一次分片线性样条
    y_lin = 0.5 * (y(1:end-1) + y(2:end));
    err1 = max(abs(y_exact - y_lin));
    err1_list(k) = err1;
    
    % 三次样条
    % 构造三对角方程组 AM = d
    n_nodes = N + 1;
    a = ones(n_nodes-1, 1); 
    b = 4 * ones(n_nodes, 1); 
    c = ones(n_nodes-1, 1); 
    d = zeros(n_nodes, 1);  
    
    % 边界条件

    b(1) = 2;
    c(1) = 1;
    d(1) = (6/h) * ((y(2) - y(1))/h - df_0);
    
    a(end) = 1;
    b(end) = 2;
    d(end) = (6/h) * (df_1 - (y(end) - y(end-1))/h);
    
    % 内部节点
    for i = 2:n_nodes-1
        d(i) = (6/h^2) * (y(i-1) - 2*y(i) + y(i+1));
    end
    
    % 求解三对角方程组
    M = thomas_algorithm(a, b, c, d);
    
    % 计算中点处的样条函数值
    y_spline = 0.5 * (y(1:end-1) + y(2:end)) - (h^2 / 16) * (M(1:end-1) + M(2:end));
    
    % 计算误差
    err2 = max(abs(y_exact - y_spline));
    err2_list(k) = err2;
    

% 计算收敛阶并输出
    if k == 1
        fprintf('%-5d %-20.6e %-15s %-20.6e %-15s\n', N, err1, '-', err2, '-');
    else
        N_old = N_list(k-1);
        ord1 = log(err1_list(k-1) / err1) / log(N / N_old);
        ord2 = log(err2_list(k-1) / err2) / log(N / N_old);
        fprintf('%-5d %-20.6e %-15.4f %-20.6e %-15.4f\n', N, err1, ord1, err2, ord2);
    end
end


% 求解三对角线性方程组函数

function x = thomas_algorithm(a, b, c, d)
    
    n = length(d);
    c_star = zeros(n-1, 1);
    d_star = zeros(n, 1);
    x = zeros(n, 1);
    
    c_star(1) = c(1) / b(1);
    d_star(1) = d(1) / b(1);
    
    for i = 2:n-1
        m = 1.0 / (b(i) - a(i-1) * c_star(i-1));
        c_star(i) = c(i) * m;
        d_star(i) = (d(i) - a(i-1) * d_star(i-1)) * m;
    end
    
    m = 1.0 / (b(n) - a(n-1) * c_star(n-1));
    d_star(n) = (d(n) - a(n-1) * d_star(n-1)) * m;
    
    x(n) = d_star(n);
    for i = n-1:-1:1
        x(i) = d_star(i) - c_star(i) * x(i+1);
    end
end