clear; clc; close all;

f = @(x) 1 ./ (1 + x.^2);
df = @(x) -2.*x ./ (1 + x.^2).^2;

x_nodes = [0, 5/3, 10/3, 5];
y_nodes = f(x_nodes);
dy_nodes = df(x_nodes);


xx = linspace(0, 5, 1000);
yy_exact = f(xx);

% 计算三种样条插值
yy_linear = linear_spline(x_nodes, y_nodes, xx);
yy_nat = nat_spline(x_nodes, y_nodes, xx);
yy_herm = hermite_spline(x_nodes, y_nodes, dy_nodes, xx);

% 绘制误差对比图
figure('Name', '误差对比图');
plot(xx, abs(yy_exact - yy_linear), 'r-', 'LineWidth', 1.5); hold on;
plot(xx, abs(yy_exact - yy_nat), 'b--', 'LineWidth', 1.5);
plot(xx, abs(yy_exact - yy_herm), 'g-.', 'LineWidth', 1.5);
legend('线性样条误差', '自然三次样条误差', '三次Hermite误差');
title('三种样条插值函数的误差对比 (4个节点)');
xlabel('x'); ylabel('绝对误差 Absolute Error');
grid on;

%加密网格、误差表与收敛阶
N_list = [5, 10, 20, 40];
err_lin = zeros(1, 4);
err_nat = zeros(1, 4);
err_herm = zeros(1, 4);

fprintf('========================= 误差与收敛阶计算 =========================\n');
fprintf(' N\t 线性误差\t 线性阶\t 自然三次误差\t 自然阶\t Hermite误差\t Hermite阶\n');
fprintf('--------------------------------------------------------------------\n');

for k = 1:length(N_list)
    N = N_list(k);
    x = linspace(0, 5, N+1);
    y = f(x);
    dy = df(x);
    
    x_mid = (x(1:end-1) + x(2:end)) / 2;
    y_mid_exact = f(x_mid);
    
    y_mid_lin = linear_spline(x, y, x_mid);
    y_mid_nat = nat_spline(x, y, x_mid);
    y_mid_herm = hermite_spline(x, y, dy, x_mid);
    
    err_lin(k) = max(abs(y_mid_exact - y_mid_lin));
    err_nat(k) = max(abs(y_mid_exact - y_mid_nat));
    err_herm(k) = max(abs(y_mid_exact - y_mid_herm));
end

% 计算收敛阶
ord_lin = [NaN, log(err_lin(1:end-1)./err_lin(2:end)) ./ log(N_list(2:end)./N_list(1:end-1))];
ord_nat = [NaN, log(err_nat(1:end-1)./err_nat(2:end)) ./ log(N_list(2:end)./N_list(1:end-1))];
ord_herm = [NaN, log(err_herm(1:end-1)./err_herm(2:end)) ./ log(N_list(2:end)./N_list(1:end-1))];

% 打印表格
for k = 1:length(N_list)
    if k == 1
        fprintf('%2d\t %.4e\t  ----\t\t %.4e\t  ----\t\t %.4e\t  ----\n', ...
            N_list(k), err_lin(k), err_nat(k), err_herm(k));
    else
        fprintf('%2d\t %.4e\t %.4f\t %.4e\t %.4f\t %.4e\t %.4f\n', ...
            N_list(k), err_lin(k), ord_lin(k), err_nat(k), ord_nat(k), err_herm(k), ord_herm(k));
    end
end
fprintf('====================================================================\n');



% 分段线性插值
function yy = linear_spline(x, y, xx)
    yy = zeros(size(xx));
    n = length(x) - 1;
    for i = 1:n
        if i == n
            idx = (xx >= x(i)) & (xx <= x(i+1));
        else
            idx = (xx >= x(i)) & (xx < x(i+1));
        end
        X = xx(idx);
        
        slope = (y(i+1) - y(i)) / (x(i+1) - x(i));
        yy(idx) = y(i) + slope * (X - x(i));
    end
end

% 自然三次样条插值
function yy = nat_spline(x, y, xx)
    n = length(x) - 1;
    h = diff(x);
    A = zeros(n+1, n+1);
    b = zeros(n+1, 1);
    
    A(1,1) = 1; A(n+1,n+1) = 1;
    
    % 构造三对角矩阵方程组
    for i = 2:n
        A(i, i-1) = h(i-1);
        A(i, i) = 2*(h(i-1) + h(i));
        A(i, i+1) = h(i);
        b(i) = 6 * ((y(i+1)-y(i))/h(i) - (y(i)-y(i-1))/h(i-1));
    end
    
    M = A \ b;
    
    yy = zeros(size(xx));
    for i = 1:n
        if i == n
            idx = (xx >= x(i)) & (xx <= x(i+1));
        else
            idx = (xx >= x(i)) & (xx < x(i+1));
        end
        X = xx(idx);
        
        % 根据 M_i 展开三次多项式
        yy(idx) = M(i)/(6*h(i)) * (x(i+1)-X).^3 + ...
                  M(i+1)/(6*h(i)) * (X-x(i)).^3 + ...
                  (y(i) - M(i)*h(i)^2/6) / h(i) * (x(i+1)-X) + ...
                  (y(i+1) - M(i+1)*h(i)^2/6) / h(i) * (X-x(i));
    end
end

% 3. 分段三次 Hermite 插值
function yy = hermite_spline(x, y, dy, xx)
    yy = zeros(size(xx));
    n = length(x) - 1;
    for i = 1:n
        if i == n
            idx = (xx >= x(i)) & (xx <= x(i+1));
        else
            idx = (xx >= x(i)) & (xx < x(i+1));
        end
        X = xx(idx);
        h = x(i+1) - x(i);
        t = (X - x(i)) / h; % 将区间映射到 [0,1] 
        
        % 构造 Hermite 四个标准基函数
        h00 = 2*t.^3 - 3*t.^2 + 1;
        h10 = t.^3 - 2*t.^2 + t;
        h01 = -2*t.^3 + 3*t.^2;
        h11 = t.^3 - t.^2;
        
        % 组合基函数得到插值结果
        yy(idx) = y(i)*h00 + h*dy(i)*h10 + y(i+1)*h01 + h*dy(i+1)*h11;
    end
end