clear; clc; format long e;

f1 = @(x) exp(-x.^2);    a1 = 0; b1 = 1;
f2 = @(x) 1./(1+x.^2);   a2 = 0; b2 = 4;
f3 = @(x) 1./(2+cos(x)); a3 = 0; b3 = 2*pi;

% 使用内置积分函数计算精确值
I1_e = integral(f1, a1, b1);
I2_e = integral(f2, a2, b2);
I3_e = integral(f3, a3, b3);
exact = [I1_e, I2_e, I3_e];

K = 7;
N_list = 2.^(1:K);

err_T = zeros(K, 3); ord_T = zeros(K, 3); 
err_G = zeros(K, 3); ord_G = zeros(K, 3); 

funcs = {f1, f2, f3};
bounds = [a1, b1; a2, b2; a3, b3];

for j = 1:3
    f = funcs{j};
    a = bounds(j, 1);
    b = bounds(j, 2);
    I_e = exact(j);
    
    for k = 1:K
        N = N_list(k);
        h = (b-a)/N;
        x = linspace(a, b, N+1);
        
        % 复化梯形
        I_T = h/2 * (f(a) + 2*sum(f(x(2:end-1))) + f(b));
        err_T(k, j) = abs(I_T - I_e);
        
        % 复化3点Gauss积分-
        t = [-sqrt(3/5), 0, sqrt(3/5)];
        w = [5/9, 8/9, 5/9];
        I_G = 0;
        
        for i = 1:N
            x0 = x(i); x1 = x(i+1);
            u = (x1-x0)/2 * t + (x1+x0)/2;
            I_G = I_G + (x1-x0)/2 * sum(w .* f(u));
        end
        err_G(k, j) = abs(I_G - I_e);
        
        if k > 1
            ord_T(k, j) = log(err_T(k-1, j)/err_T(k, j)) / log(N_list(k)/N_list(k-1));
            ord_G(k, j) = log(err_G(k-1, j)/err_G(k, j)) / log(N_list(k)/N_list(k-1));
        end
    end
end

% 打印输出表格
print_table('复化梯形公式 (Composite Trapezoidal)', N_list, err_T, ord_T);
print_table('复化3点Gauss公式 (Composite 3-Point Gauss)', N_list, err_G, ord_G);

function print_table(name, N, err, ord)
    fprintf('\n====== %s ======\n', name);
    fprintf('N\t | Error(I1)\t 阶(I1)\t | Error(I2)\t 阶(I2)\t | Error(I3)\t 阶(I3)\n');
    fprintf('----------------------------------------------------------------------------------------\n');
    for k = 1:length(N)
        if k == 1
            fprintf('%d\t | %.4e\t ----\t | %.4e\t ----\t | %.4e\t ----\n', ...
                N(k), err(k,1), err(k,2), err(k,3));
        else
            fprintf('%d\t | %.4e\t %.2f\t | %.4e\t %.2f\t | %.4e\t %.2f\n', ...
                N(k), err(k,1), ord(k,1), err(k,2), ord(k,2), err(k,3), ord(k,3));
        end
    end
end