clear; clc; close all;

f = @(x) 1 ./ (1 + 25 * x.^2); 


If = integral(f, -1, 1);

N_values = [5, 10, 15, 20, 25, 30, 35, 40];

%% 等距节点
disp('----------------------- 第一组节点 -----------------------');
disp(' N |   Int_pL(x)   |   Int_f(x)    |       Error');
disp('----------------------------------------------------------');

for k = 1:length(N_values)
    N = N_values(k);
    i_idx = 0:N;
    
    x1 = 1 - (2/N) * i_idx;
    y1 = f(x1);
    
    p1_func = @(x_eval) lagrange_interp(x1, y1, x_eval);
    Ip1 = integral(p1_func, -1, 1);
    
    err1 = abs(Ip1 - If);
    fprintf('%2d | %13.8f | %13.8f | %17.8e\n', N, Ip1, If, err1);
end
fprintf('\n');

%% 非等距节点
disp('----------------------- 第二组节点 -----------------------');
disp(' N |   Int_pL(x)   |   Int_f(x)    |       Error');
disp('----------------------------------------------------------');

for k = 1:length(N_values)
    N = N_values(k);
    i_idx = 0:N;
    
    x2 = -cos((i_idx + 1) ./ (N + 2) * pi);
    y2 = f(x2);
    
    p2_func = @(x_eval) lagrange_interp(x2, y2, x_eval);
    Ip2 = integral(p2_func, -1, 1);
    
    err2 = abs(Ip2 - If);
    fprintf('%2d | %13.8f | %13.8f | %17.8e\n', N, Ip2, If, err2);
end


%%Lagrange 插值计算函数
function p = lagrange_interp(x_nodes, y_nodes, x_eval)
    
    p = zeros(size(x_eval));
    n = length(x_nodes);
    
    for i = 1:n
        L_i = ones(size(x_eval)); 
        for j = 1:n
            if i ~= j
                L_i = L_i .* (x_eval - x_nodes(j)) / (x_nodes(i) - x_nodes(j));
            end
        end
        p = p + y_nodes(i) * L_i;
    end
end