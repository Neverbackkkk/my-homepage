clear; clc; close all;

f = @(x) 1 ./ (1 + x.^2); 


i_eval = 0:100;
y_eval = i_eval ./ 10 - 5; 
fy_eval = f(y_eval);


N_values = [5, 10, 20, 40];

% 存储 N=10 时的绘图数据
plot_y1 = zeros(size(y_eval));
plot_y2 = zeros(size(y_eval));
plot_x1 = []; plot_x2 = [];

% 主循环
for k = 1:length(N_values)
    N = N_values(k);
    
    fprintf('N=%d\n', N);
    
    i_idx = 0:N;
    
    x1 = 5 - (10/N) * i_idx;
    y1 = f(x1);
    
    x2 = -5 * cos((2 * i_idx + 1) / (2 * N + 2) * pi);
    y2 = f(x2);
    
    p1 = lagrange_interp(x1, y1, y_eval);
    p2 = lagrange_interp(x2, y2, y_eval);
    
    max_err1 = max(abs(fy_eval - p1));
    max_err2 = max(abs(fy_eval - p2));
    
    fprintf('Max Error of grid (1): %e\n', max_err1);
    fprintf('Max Error of grid (2): %e\n', max_err2);
    
    if N == 10
        plot_x1 = x1; plot_y1_nodes = y1; plot_p1 = p1;
        plot_x2 = x2; plot_y2_nodes = y2; plot_p2 = p2;
    end
end

% 绘制 N=10 时的图像
figure;
hold on;

plot(y_eval, fy_eval, 'k-', 'LineWidth', 2);

% 等距节点插值曲线及节点
plot(y_eval, plot_p1, 'r--', 'LineWidth', 1.5);
plot(plot_x1, plot_y1_nodes, 'ro', 'MarkerSize', 6);

% 切比雪夫节点插值曲线及节点
plot(y_eval, plot_p2, 'b-.', 'LineWidth', 1.5);
plot(plot_x2, plot_y2_nodes, 'b*', 'MarkerSize', 6);


legend('f(x) 原函数', 'Grid 1 插值 (等距)', 'Grid 1 节点', ...
       'Grid 2 插值 (切比雪夫)', 'Grid 2 节点', 'Location', 'Best');
title('N = 10 时的 Lagrange 插值多项式与原函数对比');
xlabel('x');
ylabel('f(x)');
grid on;
hold off;


% Lagrange 插值计算

function p = lagrange_interp(x_nodes, y_nodes, x_eval)
    n = length(x_nodes);
    m = length(x_eval);
    p = zeros(1, m);
    
    for k = 1:m
        val = 0;
        for i = 1:n
            idx = [1:i-1, i+1:n];
            L = prod((x_eval(k) - x_nodes(idx)) ./ (x_nodes(i) - x_nodes(idx)));
            val = val + y_nodes(i) * L;
        end
        p(k) = val;
    end
end